//Librerias no tocar
const express    = require('express');
const bodyParser = require('body-parser');
const path       = require('path');
const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

// Ayuda a que el servidor entienda los datos que llegan
app.use(bodyParser.urlencoded({ extended: false }));

// jala los archivos que esten publicos
app.use(express.static(path.join(__dirname, 'public')));

// Variables que ayudan a marcar la navegacion actual
app.use((req, res, next) => {
    res.locals.currentPath = req.path;
    next();
});

//Conocer el estado del servidor
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
});

// rutas a clientes
const rutasClientes = require('./routes/clientes.routes');
app.use('/clientes', rutasClientes);

// rutas a operaciones
const rutasOperaciones = require('./routes/operaciones.routes');
app.use('/operaciones', rutasOperaciones);

// rutas a alertas (Esto sirva para que cada ruta maneje cada parte
// Tipo todo lo que empiece con "/cliente"   va a pasar por "clientes.routes.js" y asi)
//Esto para no juntar todo y despues pelearnos para encontrar un problema 

const rutasAlertas = require('./routes/alertas.routes');
app.use('/alertas', rutasAlertas);

// Rutas de contratos
const rutasContratos = require('./routes/contratos.routes');
app.use('/contratos', rutasContratos);

// Rutas de reportes
const rutasReportes = require('./routes/reportes.routes');
app.use('/reportes', rutasReportes);

// Rutas de admin
const rutasAdmin = require('./routes/admin.routes');
app.use('/admin', rutasAdmin);

// Datos demo para entrar al prototipo
const usuarioDemo = {
    correo: 'demo@sofom.mx',
    password: 'demo123'
};

//cuando se entre al localhost lo primero que saldra es el inicio de sesion
app.get("/", (req, res) => {
    res.render("login", {
        usuarioDemo: usuarioDemo,
        mensaje: req.query.mensaje
    });
});

// validar el inicio de sesion demo
app.post("/login", (req, res) => {
    if (req.body.correo === usuarioDemo.correo && req.body.password === usuarioDemo.password) {
        res.redirect('/dashboard?mensaje=Sesion iniciada correctamente');
        return;
    }

    res.redirect('/?mensaje=Datos incorrectos, usa las credenciales demo');
});

// dashboard principal despues del inicio de sesion
app.get("/dashboard", (req, res) => {
    res.render("dashboard");
});

// inicia el servidor en el host 3000
const server = app.listen(3000, () => {
    console.log('Servidor listo en  http://localhost:3000');
});

// cerrar el servidor correctamente cuando se use Ctrl + C
process.on('SIGINT', () => {
    server.close(() => {
        process.exit(0);
    });
});
