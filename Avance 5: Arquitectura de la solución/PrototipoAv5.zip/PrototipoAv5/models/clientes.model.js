// Modelo para clientes

const log = console.log;

const clientes = [
    {
        idCliente: 1,
        nombre: 'Comercializadora Norte SA de CV',
        rfc: 'CNO2401189Q2',
        tipoPersona: 'Moral',
        riesgo: 'Medio',
        esPep: false,
        docs: 'Completo',
        correo: 'contacto@norte.mx',
        telefono: '555 128 9041'
    },
    {
        idCliente: 2,
        nombre: 'Mariana Lopez Torres',
        rfc: 'LOTM880921K31',
        tipoPersona: 'Fisica',
        riesgo: 'Bajo',
        esPep: false,
        docs: 'Pendiente',
        correo: 'mariana.lopez@mail.mx',
        telefono: '555 842 1102'
    },
    {
        idCliente: 3,
        nombre: 'Servicios Financieros Bajio',
        rfc: 'SFB210504JY8',
        tipoPersona: 'Moral',
        riesgo: 'Alto',
        esPep: true,
        docs: 'Revision',
        correo: 'cumplimiento@bajio.mx',
        telefono: '555 445 6180'
    }
];


// Exportamos clientes
exports.ObtenerClientes = function() {
    return clientes;
};


// Obtener clientes segun su ID
exports.ObtenerClientePorId = function(idCliente) {
    return clientes.find(function(cliente) {
        return cliente.idCliente == idCliente;
    });
};


// agregar clientes nuevos
exports.AgregarCliente = function(nuevoCliente) {
    const cliente = {
        idCliente: clientes.length + 1,
        nombre: nuevoCliente.nombre,
        rfc: nuevoCliente.rfc,
        tipoPersona: nuevoCliente.tipoPersona,
        riesgo: nuevoCliente.esPep ? 'Alto' : 'Bajo',
        esPep: nuevoCliente.esPep === 'true',
        docs: 'Pendiente',
        correo: nuevoCliente.correo,
        telefono: nuevoCliente.telefono
    };

    clientes.push(cliente);
    return cliente;
};


// Editar clientes que ya estan guardados
exports.EditarCliente = function(idCliente, datosActualizados) {
    
};


// Eliminar clientes por su ID
exports.EliminarCliente = function(idCliente) {

};
