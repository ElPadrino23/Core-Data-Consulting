// Modelo para catalogar a las alertas 

const log = console.log;

const alertas = [
    {
        idAlerta: 1,
        cliente: 'Mariana Lopez Torres',
        operacion: 'Pago $24,800',
        regla: 'Documentacion incompleta',
        nivel: 'Medio',
        fecha: '2026-04-22',
        responsable: 'Analista',
        estatus: 'Revision'
    },
    {
        idAlerta: 2,
        cliente: 'Comercializadora Norte SA de CV',
        operacion: 'Deposito $185,000',
        regla: 'Operacion frecuente',
        nivel: 'Bajo',
        fecha: '2026-04-18',
        responsable: 'Analista',
        estatus: 'Resuelta'
    }
];

// DEsplegar todas las alertas
exports.ObtenerAlertas = function() {
    return alertas;
};


// Este apartado es solo para el oficial de cumplimiento
// Aqui es donde se visualizaran las alertas y las podran resolver
exports.ResolverAlerta = function(idAlerta, datosResolucion) {
    const alerta = alertas.find(function(item) {
        return item.idAlerta == idAlerta;
    });

    if (alerta) {
        alerta.estatus = 'Resuelta';
        alerta.resolucion = datosResolucion.resolucion;
    }

    return alerta;
};



// Aqui se va a programar los umbrales de las alertas, y en caso de que:
// Operacion > SI APLICA, se convierte en alerta y se envia a ResolverAlerta
exports.GenerarAlertaSiAplica = function(operacion) {
    if (Number(operacion.monto) <= 250000) {
        return null;
    }

    const alerta = {
        idAlerta: alertas.length + 1,
        cliente: operacion.cliente,
        operacion: operacion.tipoOperacion + ' $' + operacion.monto,
        regla: 'Monto mayor a $250,000',
        nivel: 'Alto',
        fecha: operacion.fecha,
        responsable: 'Oficial de cumplimiento',
        estatus: 'Pendiente'
    };

    alertas.push(alerta);
    return alerta;
};
