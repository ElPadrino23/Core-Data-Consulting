//  Modelos para controlar operaciones 

const log = console.log;

const operaciones = [
    {
        idOperacion: 1,
        cliente: 'Comercializadora Norte SA de CV',
        contrato: 'CTR-2026-001',
        producto: 'Credito simple',
        tipoOperacion: 'Deposito',
        monto: 185000,
        moneda: 'MXN',
        fecha: '2026-04-18',
        estatus: 'Aplicada'
    },
    {
        idOperacion: 2,
        cliente: 'Mariana Lopez Torres',
        contrato: 'CTR-2026-014',
        producto: 'Credito simple',
        tipoOperacion: 'Pago',
        monto: 24800,
        moneda: 'MXN',
        fecha: '2026-04-22',
        estatus: 'Validacion'
    },
    {
        idOperacion: 3,
        cliente: 'Servicios Financieros Bajio',
        contrato: 'CTR-2026-021',
        producto: 'Factoraje',
        tipoOperacion: 'Retiro',
        monto: 520000,
        moneda: 'MXN',
        fecha: '2026-04-25',
        estatus: 'Alerta'
    }
];

let contadorId = 4;

// Exportar las operaciones
exports.ObtenerOperaciones = function() {
    return operaciones;
};

// Anadir nuevas operaciones 
exports.AgregarOperacion = function(nuevaOperacion) {
    const operacion = {
        idOperacion: contadorId,
        cliente: nuevaOperacion.cliente,
        contrato: 'CTR-2026-PEND',
        producto: 'Credito simple',
        tipoOperacion: nuevaOperacion.tipoOperacion,
        monto: Number(nuevaOperacion.monto),
        moneda: 'MXN',
        fecha: nuevaOperacion.fecha,
        estatus: Number(nuevaOperacion.monto) > 250000 ? 'Alerta' : 'Validacion'
    };

    contadorId = contadorId + 1;
    operaciones.push(operacion);
    return operacion;
};
