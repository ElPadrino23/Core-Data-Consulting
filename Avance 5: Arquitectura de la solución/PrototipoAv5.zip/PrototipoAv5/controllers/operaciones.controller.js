// COntrolar unicamente las operaciones

const modelOperaciones = require('../models/operaciones.model');
const modelAlertas     = require('../models/alertas.model');
const modelClientes    = require('../models/clientes.model');

// Mostrar todas las operaciones
module.exports.ObtenerOperaciones = async (req, res) => {
    res.render('./operaciones/lista_operaciones', {
        operaciones: modelOperaciones.ObtenerOperaciones(),
        mensaje: req.query.mensaje
    });
};

// Desplegar formulario para registrar alguna operacion
module.exports.VistaAgregarOperacion = async (req, res) => {
    res.render('./operaciones/agregar_operacion', {
        title: 'Registrar operacion',
        clientes: modelClientes.ObtenerClientes()
    });
};

// Recibir formulario y guardar operaciones nuevas
module.exports.AgregarOperacion = async (req, res) => {
    const cliente = modelClientes.ObtenerClientePorId(req.body.idCliente);
    const operacion = modelOperaciones.AgregarOperacion({
        cliente: cliente ? cliente.nombre : 'Cliente no identificado',
        tipoOperacion: req.body.tipoOperacion,
        monto: req.body.monto,
        fecha: req.body.fecha
    });

    modelAlertas.GenerarAlertaSiAplica(operacion);
    res.redirect('/operaciones/lista?mensaje=Operacion registrada para validacion');
};
