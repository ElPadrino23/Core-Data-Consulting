// Controlador de administracion

// tener la lista
module.exports.ListaUsuarios = async (req, res) => {
    const usuarios = [
        { idUsuario: 1, nombre: 'Ana Rivera', correo: 'ana.rivera@sofom.mx', rol: 'Oficial de cumplimiento', estado: 'Activo' },
        { idUsuario: 2, nombre: 'Luis Martin', correo: 'luis.martin@sofom.mx', rol: 'Analista', estado: 'Activo' }
    ];

    res.render('./admin/lista_admin', {
        usuarios: usuarios,
        mensaje: req.query.mensaje
    });
};

// funciones posteriores
module.exports.VistaAgregarUsuario = async (req, res) => {

};

module.exports.AgregarUsuario = async (req, res) => {

};

module.exports.EditarUsuario = async (req, res) => {

};

module.exports.EliminarUsuario = async (req, res) => {

};
