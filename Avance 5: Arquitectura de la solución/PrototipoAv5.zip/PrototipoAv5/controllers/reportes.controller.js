// Controlador de reportes

const reportes = [
    {
        clave: 'CNBV-01',
        nombre: 'Reporte regulatorio CNBV',
        subtitulo: 'Operaciones relevantes e inusuales',
        periodo: 'Abril 2026',
        registros: 2,
        estatus: 'Listo',
        descripcion: 'Concentra las operaciones que requieren revision regulatoria antes de enviarse a la CNBV.',
        usuario: 'Oficial de cumplimiento',
        formato: 'XML / TXT / vista previa',
        frecuencia: 'Mensual o bajo solicitud',
        salida: 'Archivo regulatorio y acuse interno',
        estructura: [
            { titulo: 'Encabezado', detalle: 'Logo SOFOM, folio, periodo, fecha de generacion, tipo de reporte, RFC institucional y oficial responsable.' },
            { titulo: 'Cuerpo', detalle: 'Tabla de operaciones con cliente, producto, monto, moneda, fecha, alerta asociada, regla disparada y dictamen.' },
            { titulo: 'Cierre', detalle: 'Totales del periodo, firma electronica, sello de tiempo y leyenda de confidencialidad regulatoria.' }
        ],
        campos: [
            { campo: 'ID operacion', origen: 'Operaciones', uso: 'Rastreo unico de la operacion reportada.' },
            { campo: 'Cliente / RFC', origen: 'Clientes', uso: 'Identifica a la persona fisica o moral relacionada.' },
            { campo: 'Tipo de operacion', origen: 'Operaciones', uso: 'Clasifica deposito, retiro, pago o disposicion.' },
            { campo: 'Monto y moneda', origen: 'Operaciones', uso: 'Permite validar umbrales regulatorios.' },
            { campo: 'Fecha de operacion', origen: 'Operaciones', uso: 'Ubica el evento dentro del periodo reportado.' },
            { campo: 'Regla disparada', origen: 'Alertas', uso: 'Explica por que la operacion entra al reporte.' },
            { campo: 'Dictamen', origen: 'Cumplimiento', uso: 'Define si es relevante o inusual.' }
        ],
        graficos: [
            { nombre: 'Operaciones por tipo', lectura: 'Compara depositos, retiros, pagos y disposiciones.' },
            { nombre: 'Riesgo del cliente', lectura: 'Muestra proporcion de clientes en riesgo alto, medio y bajo.' },
            { nombre: 'Tendencia del periodo', lectura: 'Evolucion de operaciones reportables por fecha.' }
        ],
        pie: [
            'Folio del reporte y paginacion.',
            'Firma electronica del Oficial de Cumplimiento.',
            'Sello digital de generacion.',
            'Documento confidencial para uso regulatorio.'
        ],
        ejemploHeaders: ['Operacion', 'Cliente', 'Tipo', 'Monto', 'Fecha', 'Regla', 'Dictamen'],
        muestra: [
            ['OP-003', 'Servicios Financieros Bajio', 'Retiro', '$520,000 MXN', '2026-04-25', 'Monto mayor al perfil', 'Inusual'],
            ['OP-001', 'Comercializadora Norte', 'Deposito', '$185,000 MXN', '2026-04-18', 'Operacion frecuente', 'Relevante']
        ]
    },
    {
        clave: 'INT-01',
        nombre: 'Reporte interno de seguimiento',
        subtitulo: 'Alertas y reportes internos',
        periodo: 'Abril 2026',
        registros: 0,
        estatus: 'En desarrollo',
        descripcion: 'Da seguimiento a reportes internos y alertas que requieren investigacion del area de cumplimiento.',
        usuario: 'Oficial de cumplimiento y mesa de control',
        formato: 'PDF / vista previa',
        frecuencia: 'Semanal',
        salida: 'Expediente interno de seguimiento',
        estructura: [
            { titulo: 'Encabezado', detalle: 'Folio interno, periodo, fecha de corte, responsable y estado general del seguimiento.' },
            { titulo: 'Cuerpo', detalle: 'Listado de casos con cliente relacionado, descripcion, nivel, responsable, estatus y resolucion.' },
            { titulo: 'Cierre', detalle: 'Resumen de casos pendientes, resueltos y en revision, con observaciones del responsable.' }
        ],
        campos: [
            { campo: 'ID alerta / reporte', origen: 'Alertas', uso: 'Identificador de seguimiento interno.' },
            { campo: 'Cliente relacionado', origen: 'Clientes', uso: 'Relaciona el caso con un expediente KYC.' },
            { campo: 'Descripcion del caso', origen: 'Alertas', uso: 'Explica la situacion detectada.' },
            { campo: 'Nivel de riesgo', origen: 'Alertas', uso: 'Prioriza alto, medio o bajo.' },
            { campo: 'Responsable', origen: 'Alertas', uso: 'Indica quien debe atender el caso.' },
            { campo: 'Estatus', origen: 'Alertas', uso: 'Pendiente, en revision o resuelto.' },
            { campo: 'Resolucion', origen: 'Cumplimiento', uso: 'Documenta la accion tomada.' }
        ],
        graficos: [
            { nombre: 'Casos por estatus', lectura: 'Visualiza pendientes, en revision y resueltos.' },
            { nombre: 'Casos por nivel', lectura: 'Compara casos de riesgo alto, medio y bajo.' }
        ],
        pie: [
            'Folio interno y fecha de corte.',
            'Leyenda de confidencialidad institucional.',
            'Nombre del responsable que valida el seguimiento.'
        ],
        ejemploHeaders: ['Caso', 'Cliente', 'Nivel', 'Responsable', 'Estatus', 'Resolucion'],
        muestra: [
            ['AL-001', 'Servicios Financieros Bajio', 'Alto', 'Oficial de cumplimiento', 'Pendiente', 'En analisis'],
            ['AL-002', 'Mariana Lopez Torres', 'Medio', 'Analista', 'Revision', 'Solicitar documentos']
        ]
    },
    {
        clave: 'DASH-01',
        nombre: 'Reporte operativo del dashboard',
        subtitulo: 'Indicadores de operacion y riesgo',
        periodo: 'Abril 2026',
        registros: 0,
        estatus: 'En desarrollo',
        descripcion: 'Resume el estado operativo del sistema para tomar decisiones rapidas sobre clientes, operaciones, alertas y reportes.',
        usuario: 'Administrador, analista PLD y oficial de cumplimiento',
        formato: 'Vista dashboard / PDF ejecutivo',
        frecuencia: 'Diaria',
        salida: 'Resumen ejecutivo interno',
        estructura: [
            { titulo: 'Encabezado', detalle: 'Nombre del tablero, usuario, rol activo, fecha y hora de actualizacion.' },
            { titulo: 'Cuerpo', detalle: 'Tarjetas KPI, ultimas alertas, operaciones recientes y distribucion de clientes por riesgo.' },
            { titulo: 'Cierre', detalle: 'Fecha de consulta, usuario que genero el resumen y notas de seguimiento.' }
        ],
        campos: [
            { campo: 'Clientes activos', origen: 'Clientes', uso: 'Mide la base activa de expedientes.' },
            { campo: 'Operaciones del mes', origen: 'Operaciones', uso: 'Resume actividad transaccional.' },
            { campo: 'Alertas pendientes', origen: 'Alertas', uso: 'Marca carga de trabajo de cumplimiento.' },
            { campo: 'Reportes listos', origen: 'Reportes', uso: 'Indica reportes preparados para revision o envio.' },
            { campo: 'Distribucion de riesgo', origen: 'Clientes', uso: 'Agrupa clientes por riesgo bajo, medio y alto.' },
            { campo: 'Alertas recientes', origen: 'Alertas', uso: 'Muestra los casos mas nuevos para priorizar.' }
        ],
        graficos: [
            { nombre: 'Tarjetas KPI', lectura: 'Indicadores principales con color por prioridad.' },
            { nombre: 'Barras por riesgo', lectura: 'Cantidad de clientes bajo, medio y alto.' },
            { nombre: 'Linea de alertas', lectura: 'Tendencia de alertas de los ultimos 30 dias.' }
        ],
        pie: [
            'Fecha y hora de consulta.',
            'Usuario que genero el resumen.',
            'Uso interno para toma de decisiones.'
        ],
        ejemploHeaders: ['Indicador', 'Valor', 'Lectura', 'Prioridad'],
        muestra: [
            ['Clientes activos', '3', 'Base actual de expedientes', 'Normal'],
            ['Alertas pendientes', '2', 'Requiere seguimiento', 'Media'],
            ['Reportes listos', '2', 'Listos para revision', 'Normal']
        ]
    }
];

module.exports.LoginReportes = async (req, res) => {
    res.render('./reportes/lista_reportes', {
        reportes: reportes,
        mensaje: req.query.mensaje
    });
};

module.exports.DetalleReporte = async (req, res) => {
    const reporte = reportes.find(function(item) {
        return item.clave === req.params.clave;
    });

    if (!reporte || reporte.clave !== 'CNBV-01') {
        res.redirect('/reportes/lista?mensaje=En desarrollo');
        return;
    }

    res.render('./reportes/detalle_reporte', {
        reporte: reporte,
        mensaje: req.query.mensaje
    });
};

module.exports.GenerarReporte = async (req, res) => {

};

module.exports.ListaReportes = async (req, res) => {

};
