// Controlar todo el apartado de los clientes

const modelClientes = require('../models/clientes.model');

// Aqui exportaremos todos los datos de los clientes desde la BD
module.exports.ObtenerClientes = async (req, res) => {
    res.render('./clientes/lista_clientes', {
        clientes: modelClientes.ObtenerClientes(),
        mensaje: req.query.mensaje
    });
};

// Agregar a un cliente
module.exports.VistaAgregarCliente = async (req, res) => {
    res.render('./clientes/agregar_cliente', {
        title: 'Registrar cliente'
    });
};

// ver formulario y agregar a un nuevo cliente
module.exports.AgregarCliente = async (req, res) => {
    modelClientes.AgregarCliente(req.body);
    res.redirect('/clientes/lista?mensaje=Cliente registrado correctamente');
};

// Aqui desplegaremos un menu para editar clientes
module.exports.VistaEditarCliente = async (req, res) => {

};

// Obtener el formulario del cliente y poder modificarlo
module.exports.EditarCliente = async (req, res) => {

};

// Borrar clientes
module.exports.EliminarCliente = async (req, res) => {

};
