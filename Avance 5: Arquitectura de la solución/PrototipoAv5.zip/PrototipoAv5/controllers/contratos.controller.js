// Controlador de contratos

// Mostrar lista de contratos
module.exports.ObtenerContratos = async (req, res) => {
    const contratos = [
        { idContrato: 1, cliente: 'Comercializadora Norte SA de CV', producto: 'Credito simple', inicio: '2026-01-10', vencimiento: '2027-01-10', saldo: 840000, estatus: 'Activo' },
        { idContrato: 2, cliente: 'Mariana Lopez Torres', producto: 'Arrendamiento', inicio: '2026-02-18', vencimiento: '2028-02-18', saldo: 310000, estatus: 'Activo' },
        { idContrato: 3, cliente: 'Servicios Financieros Bajio', producto: 'Factoraje', inicio: '2026-03-02', vencimiento: '2026-09-02', saldo: 1250000, estatus: 'Revision' }
    ];

    res.render('./contratos/lista_contratos', {
        contratos: contratos,
        mensaje: req.query.mensaje
    });
};


module.exports.VistaAgregarContrato = async (req, res) => {

};

module.exports.AgregarContrato = async (req, res) => {

};
