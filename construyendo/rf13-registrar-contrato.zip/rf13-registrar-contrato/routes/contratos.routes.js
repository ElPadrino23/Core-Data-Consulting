// ─── SNIPPET PARA AGREGAR A TU ARCHIVO DE RUTAS ───────────────────────────────
// Pega esto en routes/contratos.routes.js (o donde tengas las rutas de contratos)
// Si no existe ese archivo, crea uno nuevo y registralo en app.js

const express = require('express');
const router = express.Router();
const contratosController = require('../controllers/contratos.controller');

// lista de contratos (GET /contratos)
router.get('/', contratosController.listarContratos);

// formulario para contrato nuevo (GET /contratos/nuevo)
router.get('/nuevo', contratosController.mostrarFormularioNuevo);

// guardar contrato nuevo (POST /contratos/nuevo)
router.post('/nuevo', contratosController.crearContrato);

module.exports = router;


// ─── EN app.js AGREGA ESTA LÍNEA (si no está ya) ─────────────────────────────
// const contratosRoutes = require('./routes/contratos.routes');
// app.use('/contratos', contratosRoutes);
