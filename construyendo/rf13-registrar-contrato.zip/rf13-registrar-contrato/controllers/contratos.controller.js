// controlador de contratos - maneja las rutas de lista, formulario y guardado
const contratosModel = require('../models/contratos.model');

// muestra la lista de todos los contratos
async function listarContratos(req, res) {
  try {
    const contratos = await contratosModel.obtenerContratos();
    res.render('contratos/lista', { contratos });
  } catch (error) {
    console.error('Error al obtener contratos:', error.message);
    res.status(500).send('Error al cargar los contratos');
  }
}

// muestra el formulario para registrar un contrato nuevo
async function mostrarFormularioNuevo(req, res) {
  try {
    // necesitamos los clientes para el select del formulario
    const clientes = await contratosModel.obtenerClientesParaSelect();
    res.render('contratos/nuevo', {
      clientes,
      // si hay un mensaje de error del redirect anterior lo pasamos
      error: req.query.error || null
    });
  } catch (error) {
    console.error('Error al cargar formulario de contrato:', error.message);
    res.status(500).send('Error al cargar el formulario');
  }
}

// procesa el POST del formulario y guarda el contrato
async function crearContrato(req, res) {
  try {
    const { idcliente, producto, fecha_inicio, vencimiento, saldo, estatus } = req.body;

    // validación básica antes de ir a supabase
    if (!idcliente || !producto || !fecha_inicio) {
      return res.redirect('/contratos/nuevo?error=Campos+obligatorios+incompletos');
    }

    await contratosModel.crearContrato({ idcliente, producto, fecha_inicio, vencimiento, saldo, estatus });

    // regresamos a la lista con mensaje de éxito
    res.redirect('/contratos?exito=Contrato+registrado+correctamente');
  } catch (error) {
    console.error('Error al crear contrato:', error.message);
    res.redirect('/contratos/nuevo?error=Error+al+guardar+el+contrato');
  }
}

module.exports = { listarContratos, mostrarFormularioNuevo, crearContrato };
