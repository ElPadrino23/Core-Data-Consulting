// modelo de contratos - maneja todo lo relacionado con la tabla contratos en supabase
const supabase = require('../config/supabase');

// trae todos los contratos, uniendo con clientes para mostrar el nombre
async function obtenerContratos() {
  const { data, error } = await supabase
    .from('contratos')
    .select(`
      id,
      idcliente,
      producto,
      fecha_inicio,
      vencimiento,
      saldo,
      estatus,
      clientes ( nombre )
    `)
    .order('id', { ascending: false });

  if (error) throw error;
  return data;
}

// inserta un contrato nuevo en la base de datos
async function crearContrato({ idcliente, producto, fecha_inicio, vencimiento, saldo, estatus }) {
  const { data, error } = await supabase
    .from('contratos')
    .insert([
      {
        idcliente: parseInt(idcliente),
        producto,
        fecha_inicio,
        // vencimiento es opcional, si viene vacío lo dejamos null
        vencimiento: vencimiento || null,
        saldo: parseFloat(saldo) || 0,
        estatus: estatus || 'VIGENTE'
      }
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
}

// trae solo los clientes para el select del formulario
async function obtenerClientesParaSelect() {
  const { data, error } = await supabase
    .from('clientes')
    .select('id, nombre')
    .order('nombre', { ascending: true });

  if (error) throw error;
  return data;
}

module.exports = { obtenerContratos, crearContrato, obtenerClientesParaSelect };
