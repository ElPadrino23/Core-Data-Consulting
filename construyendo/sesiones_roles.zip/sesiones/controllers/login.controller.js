// Controller login y autenticacion - con manejo de sesion

const modelLogin = require('../models/login.model');

// Usuario de acceso rapido para demo/pruebas
const usuarioDemo = {
    correo:   'demo@sofom.mx',
    password: 'demo123',
    nombre:   'Usuario Demo',
    rol:      'Administrador'
};

// Vista de login
module.exports.VistaLogin = async (req, res) => {
    // Si ya hay sesion activa, manda directo al dashboard
    if (req.session && req.session.usuario) {
        return res.redirect('/dashboard');
    }
    res.render('./login/login', {
        usuarioDemo: usuarioDemo,
        mensaje:     req.query.mensaje || null
    });
};

// Procesar login: verifica demo primero, luego Supabase
module.exports.ProcesarLogin = async (req, res) => {
    const { correo, password } = req.body;

    // Acceso rapido demo - asigna rol de Administrador
    if (correo === usuarioDemo.correo && password === usuarioDemo.password) {
        req.session.usuario = {
            id:     0,
            nombre: usuarioDemo.nombre,
            correo: usuarioDemo.correo,
            rol:    usuarioDemo.rol
        };
        return res.redirect('/dashboard');
    }

    try {
        const usuario = await modelLogin.ValidarCredenciales(correo, password);

        if (usuario) {
            // Guardar datos del usuario en la sesion
            req.session.usuario = {
                id:     usuario.id,
                nombre: usuario.nombre,
                correo: usuario.correo,
                rol:    usuario.rol
            };
            return res.redirect('/dashboard');
        }

        res.redirect('/login?mensaje=Datos incorrectos. Verifica tu correo y contrasena.');
    } catch (error) {
        res.redirect('/login?mensaje=No fue posible conectar con la base de datos. Usa el acceso rapido.');
    }
};

// Logout: destruye la sesion
module.exports.Logout = async (req, res) => {
    req.session.destroy(function(err) {
        res.redirect('/login');
    });
};

// Vista de registro (sin cambios)
module.exports.VistaRegistro = async (req, res) => {
    res.render('./login/login', {
        usuarioDemo: usuarioDemo,
        mensaje:     null
    });
};

// Procesar registro (sin cambios)
module.exports.ProcesarRegistro = async (req, res) => {
    res.redirect('/login');
};
