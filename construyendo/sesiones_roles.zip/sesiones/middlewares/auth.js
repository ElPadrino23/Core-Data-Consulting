// Middleware de autenticacion y control de roles - CoreData Consulting

// Verifica que haya una sesion activa antes de continuar
function verificarSesion(req, res, next) {
    if (req.session && req.session.usuario) {
        return next();
    }
    res.redirect('/login?mensaje=Debes iniciar sesion para continuar.');
}

// Verifica que el usuario tenga uno de los roles permitidos
// Uso: verificarRol('Administrador', 'Oficial de Cumplimiento')
function verificarRol(...roles) {
    return function(req, res, next) {
        if (!req.session || !req.session.usuario) {
            return res.redirect('/login?mensaje=Debes iniciar sesion para continuar.');
        }

        const rolUsuario = req.session.usuario.rol;

        if (roles.includes(rolUsuario)) {
            return next();
        }

        // Si tiene sesion pero no el rol requerido, manda al dashboard con aviso
        res.redirect('/dashboard?mensaje=No tienes permiso para acceder a esa seccion.');
    };
}

module.exports = { verificarSesion, verificarRol };
