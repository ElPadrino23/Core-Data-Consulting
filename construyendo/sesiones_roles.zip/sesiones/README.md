# Sesiones y Control de Roles — CoreData Consulting

## Qué hace este parche

Implementa autenticación con sesión real y control de acceso basado en roles (RBAC)
para los tres roles del sistema: Analista, Oficial de Cumplimiento y Administrador.

Cubre directamente RN-05 (solo el Oficial resuelve alertas) y RF-19 (solo Admin
gestiona usuarios), que antes no tenían ninguna protección en el código.

---

## Pasos para integrar

### 1. Instalar express-session

```bash
npm install express-session
```

O simplemente reemplaza tu package.json con el que viene en este zip y corre:

```bash
npm install
```

---

### 2. Copiar archivos nuevos/modificados

Reemplaza en tu proyecto los siguientes archivos:

| Archivo en el zip                        | Destino en el proyecto                    |
|------------------------------------------|-------------------------------------------|
| middlewares/auth.js                      | middlewares/auth.js  (carpeta nueva)      |
| controllers/login.controller.js          | controllers/login.controller.js           |
| routes/alertas.routes.js                 | routes/alertas.routes.js                  |
| views/nav.ejs                            | views/nav.ejs                             |
| index.js                                 | index.js                                  |
| package.json                             | package.json                              |

---

### 3. Agregar CSS del sidebar (opcional pero recomendado)

Abre views/css.ejs y pega al final del bloque <style> el contenido
del archivo sidebar-user.css.txt. Esto muestra el nombre y rol del
usuario logueado en el menú lateral.

---

## Cómo funciona

### Sesión
Al hacer login, el controller guarda en req.session.usuario:
  { id, nombre, correo, rol }

Ese objeto se inyecta automáticamente a todas las vistas via res.locals.usuario,
por eso el nav.ejs puede leer usuario.rol sin que cada controller lo tenga que pasar.

### Middleware verificarSesion
Protege cualquier ruta: si no hay sesión activa, redirige al login.
Se aplica en index.js antes de montar cada grupo de rutas.

### Middleware verificarRol(...roles)
Verifica que el rol del usuario en sesión esté en la lista permitida.
Si no, redirige al dashboard con un mensaje de acceso denegado.

Ejemplos de uso:
  verificarRol('Administrador')
  verificarRol('Oficial de Cumplimiento', 'Administrador')

### Qué ve cada rol en el menú

| Sección           | Analista | Oficial | Administrador |
|-------------------|----------|---------|---------------|
| Clientes          | ✓        | ✓       | ✓             |
| Operaciones       | ✓        | ✓       | ✓             |
| Alertas (ver)     | ✓        | ✓       | ✓             |
| Alertas (resolver)|          | ✓       | ✓             |
| Contratos         | ✓        | ✓       | ✓             |
| Reportes          |          | ✓       | ✓             |
| Canal interno     | ✓        | ✓       | ✓             |
| Reglas            |          | ✓       | ✓             |
| Historial         |          | ✓       | ✓             |
| Admin             |          |         | ✓             |

### Roles en Supabase
Los usuarios en la tabla `usuario` deben tener el campo `rol` con uno de estos valores exactos:
  - Analista
  - Oficial de Cumplimiento
  - Administrador

El usuario demo (demo@sofom.mx) tiene rol Administrador por defecto.

### Logout
El link de "Cerrar sesion" apunta ahora a /login/logout (antes apuntaba a /login).
Eso destruye la sesión correctamente. Asegúrate de que tu nav.ejs use la versión
incluida en este zip.
