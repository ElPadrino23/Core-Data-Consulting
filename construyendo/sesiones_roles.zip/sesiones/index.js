// index - CoreData Consulting

// Librerias no tocar
const express    = require('express');
const bodyParser = require('body-parser');
const path       = require('path');
const fileUpload = require('express-fileupload');
const session    = require('express-session');
const app = express();

const modelClientes    = require('./models/clientes.model');
const modelOperaciones = require('./models/operaciones.model');
const modelAlertas     = require('./models/alertas.model');

// Middlewares de autenticacion y roles
const { verificarSesion, verificarRol } = require('./middlewares/auth');

// Notificar el uso de ejs
app.set('view engine', 'ejs');
app.set('views', 'views');

// Configuracion de sesiones
app.use(session({
    secret:            'coredata-pld-secret-2026',
    resave:            false,
    saveUninitialized: false,
    cookie: {
        maxAge:   1000 * 60 * 60 * 8, // 8 horas
        httpOnly: true
    }
}));

// Middleware para archivos
app.use(fileUpload());

// Middleware para parsear datos
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Jala los archivos que esten publicos
app.use(express.static(path.join(__dirname, 'public')));

// Marca la ruta activa y expone el usuario de sesion a todas las vistas
app.use((req, res, next) => {
    res.locals.currentPath = req.path;
    res.locals.usuario     = req.session.usuario || null;
    next();
});

// Conocer el estado del servidor
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
});

// ----- RUTAS DE LOGIN (publicas, sin proteccion) -----
const rutasLogin = require('./routes/login.routes');
app.use('/login', rutasLogin);

// Ruta raiz redirige al login
app.get('/', (req, res) => {
    res.redirect('/login');
});

// ----- DASHBOARD (requiere sesion) -----
app.get('/dashboard', verificarSesion, (req, res) => {
    res.render('dashboard', { mensaje: req.query.mensaje || null });
});

// API para los contadores del dashboard
app.get('/api/dashboard', verificarSesion, async (req, res) => {
    try {
        const resultadoClientes    = await modelClientes.ObtenerClientesLista();
        const resultadoOperaciones = await modelOperaciones.ObtenerOperaciones();
        const resultadoAlertas     = await modelAlertas.ObtenerAlertas();

        const clientes    = resultadoClientes.clientes || [];
        const operaciones = resultadoOperaciones.operaciones || [];
        const alertas     = resultadoAlertas.alertas || [];

        // Ultimas 5 alertas para el dashboard
        const alertasRecientes = alertas.slice(0, 5).map(function(a) {
            return {
                descripcion: a.regla || ('Operacion #' + (a.idoperacion || '')),
                nivel:       a.nivel || '',
                estatus:     a.estatus || '',
                fecha:       a.fecha || ''
            };
        });

        // Distribucion de clientes por nivel de riesgo
        const distribucionRiesgo = ['Bajo', 'Medio', 'Alto'].map(function(nivel) {
            return {
                nivel:    nivel,
                cantidad: clientes.filter(function(c) { return c.nivelriesgo === nivel; }).length
            };
        });

        res.json({
            totalClientes:          clientes.length,
            totalOperaciones:       operaciones.length,
            totalAlertasPendientes: alertas.filter(function(a) { return a.estatus !== 'Resuelta'; }).length,
            totalReportesListos:    0,
            alertasRecientes:       alertasRecientes,
            distribucionRiesgo:     distribucionRiesgo
        });
    } catch (error) {
        res.json({
            totalClientes: 0, totalOperaciones: 0,
            totalAlertasPendientes: 0, totalReportesListos: 0,
            alertasRecientes: [], distribucionRiesgo: []
        });
    }
});

// ----- CLIENTES (Analista, Oficial, Administrador) -----
const rutasClientes = require('./routes/clientes.routes');
app.use('/clientes', verificarSesion, rutasClientes);

// ----- OPERACIONES (Analista, Oficial, Administrador) -----
const rutasOperaciones = require('./routes/operaciones.routes');
app.use('/operaciones', verificarSesion, rutasOperaciones);

// ----- ALERTAS (lista/detalle: todos | resolver: solo Oficial y Admin) -----
const rutasAlertas = require('./routes/alertas.routes');
app.use('/alertas', verificarSesion, rutasAlertas);

// ----- CONTRATOS (Analista, Oficial, Administrador) -----
const rutasContratos = require('./routes/contratos.routes');
app.use('/contratos', verificarSesion, rutasContratos);

// ----- REPORTES (Oficial, Administrador) -----
const rutasReportes = require('./routes/reportes.routes');
app.use('/reportes', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Administrador'), rutasReportes);

// ----- ADMIN (solo Administrador) -----
const rutasAdmin = require('./routes/admin.routes');
app.use('/admin', verificarSesion, verificarRol('Administrador'), rutasAdmin);

// ----- REGLAS (Oficial, Administrador) -----
const rutasReglas = require('./routes/reglas.routes');
app.use('/reglas', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Administrador'), rutasReglas);

// ----- HISTORIAL (Oficial, Administrador) -----
const rutasHistorial = require('./routes/historial.routes');
app.use('/historial', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Administrador'), rutasHistorial);

// ----- REPORTES INTERNOS (todos los autenticados pueden reportar) -----
const rutasReportesInternos = require('./routes/reportes_internos.routes');
app.use('/reportes-internos', verificarSesion, rutasReportesInternos);

// Manejador de errores global
app.use((error, req, res, next) => {
    console.error(error.message);

    if (req.path.includes('/api/')) {
        res.status(503).json({
            msg:     'No fue posible consultar la base de datos',
            detalle: error.message
        });
        return;
    }

    next(error);
});

// Inicia el servidor en el host 3000
const server = app.listen(3000, () => {
    console.log('-> http://localhost:3000');
});

// Cerrar el servidor correctamente cuando se use Ctrl + C
process.on('SIGINT', () => {
    server.close(() => {
        process.exit(0);
    });
});
