// Rutas para las alertas

const express           = require('express');
const router            = express.Router();
const controllerAlertas = require('../controllers/alertas.controller');
const { verificarRol }  = require('../middlewares/auth');

// Mostrar las alertas (todos los roles)
router.get('/lista', controllerAlertas.ObtenerAlertas);

// API JSON para el frontend (todos los roles)
router.get('/api/lista', controllerAlertas.ApiListaAlertas);

// Detalle de alerta con historial del cliente (todos los roles)
router.get('/detalle', controllerAlertas.VistaDetalleAlerta);

// Resolver / cambiar estatus: solo Oficial de Cumplimiento y Administrador (RN-05)
router.post('/api/resolver',        verificarRol('Oficial de Cumplimiento', 'Administrador'), controllerAlertas.ApiResolverAlerta);
router.post('/api/estatus',         verificarRol('Oficial de Cumplimiento', 'Administrador'), controllerAlertas.ApiCambiarEstatus);
router.post('/resolver-detalle',    verificarRol('Oficial de Cumplimiento', 'Administrador'), controllerAlertas.ProcesarResolucion);

// Vista formulario resolver (solo Oficial y Admin)
router.get('/resolver',  verificarRol('Oficial de Cumplimiento', 'Administrador'), controllerAlertas.VistaResolverAlerta);
router.post('/resolver', verificarRol('Oficial de Cumplimiento', 'Administrador'), controllerAlertas.ResolverAlerta);

module.exports = router;
