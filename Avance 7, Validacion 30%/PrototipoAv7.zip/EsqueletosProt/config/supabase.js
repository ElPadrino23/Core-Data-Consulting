// NO TOCAR POR FAVOOOOORRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
// SIN ESTO NO EXISTE RUTA CON SUPABASE


const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://ylrqhxappjzwefzblglr.supabase.co';
const supabaseAnonKey = 'sb_secret_TfCq7GHhKdcUlkCs5pmnyw_LzVOWqf8';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

module.exports = supabase;