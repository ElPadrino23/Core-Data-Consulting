// Modelo para alertas PLD

const supabase = require('../config/supabase');

// Obtener todas las alertas
exports.ObtenerAlertas = async function() {
    try {
        const { data: alertas, error } = await supabase
            .from('alerta')
            .select('*')
            .order('idalerta', { ascending: false });

        if (error) throw new Error(error.message);
        return { exito: true, alertas: alertas || [] };
    } catch (error) {
        return { exito: false, alertas: [], error: error.message };
    }
};

// Resolver una alerta cambiando su estatus
exports.ResolverAlerta = async function(idAlerta, datosResolucion) {
    try {
        const { error } = await supabase
            .from('alerta')
            .update({
                estatus:    'Resuelta',
                resolucion: datosResolucion.resolucion || ''
            })
            .eq('idalerta', idAlerta);

        if (error) throw new Error(error.message);
        return { exito: true };
    } catch (error) {
        return { exito: false, error: error.message };
    }
};

// Generar una alerta si la operacion supera los umbrales
exports.GenerarAlertaSiAplica = async function(operacion) {
    // Umbral: operaciones mayores a 600,000 MXN generan alerta automatica
    const monto = parseFloat(operacion.monto) || 0;

    if (monto >= 600000) {
        try {
            await supabase.from('alerta').insert([{
                idoperacion: operacion.idoperacion,
                idcliente:   operacion.idcliente,
                nivel:       monto >= 1500000 ? 'Alto' : 'Medio',
                estatus:     'Pendiente',
                fecha:       new Date().toISOString().split('T')[0]
            }]);
        } catch (err) {
            console.error('Error al generar alerta:', err.message);
        }
    }
};
