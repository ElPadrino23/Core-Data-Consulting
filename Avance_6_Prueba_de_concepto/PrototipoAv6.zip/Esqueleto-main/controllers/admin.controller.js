// Controlador de administracion de usuarios

const supabase = require('../config/supabase');

// Vista lista de usuarios
module.exports.ListaUsuarios = async (req, res) => {
    res.render('./admin/lista_admin', {
        mensaje: req.query.mensaje || null
    });
};

// API: devuelve usuarios como JSON para el frontend
module.exports.ApiListaUsuarios = async (req, res) => {
    try {
        const { data: rows, error } = await supabase
            .from('usuario')
            .select('*')
            .order('idusuario', { ascending: false });

        if (error) throw new Error(error.message);

        const usuarios = (rows || []).map(function(u) {
            return {
                idUsuario: u.idusuario || u.id_usuario || u.id,
                nombre:    [u.nombre || '', u.apellido || ''].join(' ').trim(),
                correo:    u.correo || u.email || '',
                rol:       u.rol || 'Usuario',
                estado:    u.activo === false ? 'Inactivo' : 'Activo'
            };
        });

        res.json({ usuarios: usuarios });
    } catch (error) {
        // Tabla no creada aun - devolver vacio sin romper el frontend
        res.json({ usuarios: [], nota: 'Tabla usuario pendiente en Supabase' });
    }
};

module.exports.VistaAgregarUsuario = async (req, res) => {
};

module.exports.AgregarUsuario = async (req, res) => {
};

module.exports.EditarUsuario = async (req, res) => {
};

module.exports.EliminarUsuario = async (req, res) => {
};
