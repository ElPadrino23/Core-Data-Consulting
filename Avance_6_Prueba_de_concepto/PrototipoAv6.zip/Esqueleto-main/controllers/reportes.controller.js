// Controlador de reportes

const supabase = require('../config/supabase');

// Vista lista de reportes
module.exports.LoginReportes = async (req, res) => {
    res.render('./reportes/lista_reportes', {
        mensaje: req.query.mensaje || null
    });
};

// API: devuelve reportes como JSON para el frontend
module.exports.ApiListaReportes = async (req, res) => {
    try {
        const { data: rows, error } = await supabase
            .from('reporte')
            .select('*')
            .order('idreporte', { ascending: false });

        if (error) throw new Error(error.message);

        const reportes = (rows || []).map(function(r) {
            return {
                idReporte: r.idreporte,
                clave:     r.clave || '',
                nombre:    r.nombre || '',
                periodo:   r.periodo || '',
                registros: r.registros || 0,
                estatus:   r.estatus || '',
                formato:   r.formato || ''
            };
        });

        res.json({ reportes: reportes });
    } catch (error) {
        // Tabla no creada aun - devolver vacio sin romper el frontend
        res.json({ reportes: [], nota: 'Tabla reporte pendiente en Supabase' });
    }
};

module.exports.GenerarReporte = async (req, res) => {
};

module.exports.ListaReportes = async (req, res) => {
};
