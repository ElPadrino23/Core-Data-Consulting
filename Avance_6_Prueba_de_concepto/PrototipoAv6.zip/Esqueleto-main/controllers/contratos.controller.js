// Controlador de contratos

const supabase = require('../config/supabase');

// Vista lista de contratos
module.exports.ObtenerContratos = async (req, res) => {
    res.render('./contratos/lista_contratos', {
        mensaje: req.query.mensaje || null
    });
};

// API: devuelve contratos como JSON para el frontend
module.exports.ApiListaContratos = async (req, res) => {
    try {
        const { data: rows, error } = await supabase
            .from('contrato')
            .select('*')
            .order('idcontrato', { ascending: false });

        if (error) throw new Error(error.message);

        const contratos = (rows || []).map(function(c) {
            return {
                idContrato:  c.idcontrato,
                cliente:     c.idcliente || '',
                producto:    c.producto || '',
                inicio:      c.fechainicio || c.fecha_inicio || '',
                vencimiento: c.vencimiento || c.fecha_vencimiento || '',
                saldo:       c.saldo || 0,
                estatus:     c.estatus || ''
            };
        });

        res.json({ contratos: contratos });
    } catch (error) {
        // Tabla no creada aun - devolver vacio sin romper el frontend
        res.json({ contratos: [], nota: 'Tabla contrato pendiente en Supabase' });
    }
};

module.exports.VistaAgregarContrato = async (req, res) => {
};

module.exports.AgregarContrato = async (req, res) => {
};
